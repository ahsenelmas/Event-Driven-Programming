# edp-student
Event driven system modeling the process of student applying to foreign university
